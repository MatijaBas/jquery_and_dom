$(document).ready(function() {
 //
 // add your jQuery code here
 $("button").mouseenter(function() {
  $(this).removeClass("makeRed").addClass("makeBorder");
 });
 
 $("button").mouseleave(function() {
  $("button").removeClass("makeBorder").addClass("makeRed");
 });
 
 $("button").click(function(){
        $('p').slideToggle('2000');
    });
    
    $("button").click(function(){
        $('p').hide('slow').show("fast");
    });
  $("button").click(function(){
		 $("p").fadeIn().fadeOut();
	});
}); 
